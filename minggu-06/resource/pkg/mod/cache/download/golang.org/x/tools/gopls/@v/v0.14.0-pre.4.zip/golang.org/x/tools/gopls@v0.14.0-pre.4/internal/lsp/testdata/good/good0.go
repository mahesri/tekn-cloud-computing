package good

func stuff() { //@item(good_stuff, "stuff", "func()", "func"),prepare("stu", "stuff", "stuff")
	x := 5
	random2(x) //@prepare("dom", "random2", "random2")
}
